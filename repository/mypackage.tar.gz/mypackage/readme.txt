Teste do Pkg escrito em Lua
